// options.js - Settings: master password, security questions, lock preferences
import { hashPassword, verifyPassword } from './crypto-utils.js';
import {
  SECURITY_QUESTIONS,
  sanitizeIntegerInput,
  buildSecurityRecord,
  hasSecurityQuestions,
  clearRecoveryFailures
} from './security-utils.js';

const $ = (id) => document.getElementById(id);

const currentPasswordWrapper = $('currentPasswordWrapper');
const currentPasswordInput = $('currentPassword');
const newPasswordInput = $('newPassword');
const confirmPasswordInput = $('confirmPassword');
const passwordForm = $('passwordForm');
const passwordStatus = $('passwordStatus');
const passwordSectionTitle = $('passwordSectionTitle');
const savePasswordBtn = $('savePasswordBtn');

const recoveryFieldWrapper = $('recoveryFieldWrapper');
const setupQuestions = $('setupQuestions');

const recoveryCard = $('recoveryCard');
const recoveryBadge = $('recoveryBadge');
const recoveryForm = $('recoveryForm');
const editQuestions = $('editQuestions');
const recoveryPassword = $('recoveryPassword');
const recoveryStatus = $('recoveryStatus');

const lockOnStartupCheckbox = $('lockOnStartup');
const autoLockSelect = $('autoLockMinutes');
const prefStatus = $('prefStatus');
const lockNowBtn = $('lockNowBtn');

function setStatus(el, message, ok = false) {
  el.style.color = ok ? '#22c55e' : '#ef4444';
  el.textContent = message;
}

// ---------- Security question fields ----------
// Builds one labelled input per question inside `container`.
// Returns { name: <input>, years: <input>, crush: <input> }
function renderQuestionFields(container, idPrefix) {
  const inputs = {};
  container.textContent = '';

  SECURITY_QUESTIONS.forEach((q, index) => {
    const field = document.createElement('div');
    field.className = 'field';

    const label = document.createElement('label');
    label.htmlFor = `${idPrefix}-${q.id}`;
    label.textContent = `${index + 1}. ${q.label}`;

    const input = document.createElement('input');
    input.type = 'text';
    input.id = `${idPrefix}-${q.id}`;
    input.placeholder = q.placeholder;
    input.autocomplete = 'off';
    input.spellcheck = false;
    if (q.type === 'integer') {
      input.inputMode = 'numeric';
      input.maxLength = 4;
      input.addEventListener('input', () => sanitizeIntegerInput(input));
    }

    field.append(label, input);
    container.appendChild(field);
    inputs[q.id] = input;
  });

  return inputs;
}

function readAnswers(inputs) {
  const answers = {};
  SECURITY_QUESTIONS.forEach((q) => {
    answers[q.id] = inputs[q.id].value;
  });
  return answers;
}

function clearAnswers(inputs) {
  Object.values(inputs).forEach((input) => { input.value = ''; });
}

const setupInputs = renderQuestionFields(setupQuestions, 'setup');
const editInputs = renderQuestionFields(editQuestions, 'edit');

// ---------- Load ----------
async function loadSettings() {
  const { isLocked } = await chrome.storage.session.get('isLocked');
  if (isLocked) {
    window.location.href = chrome.runtime.getURL('lock.html');
    return;
  }

  const { passwordHash, lockOnStartup, autoLockMinutes } =
    await chrome.storage.local.get(['passwordHash', 'lockOnStartup', 'autoLockMinutes']);

  if (passwordHash) {
    currentPasswordWrapper.style.display = 'block';
    recoveryFieldWrapper.classList.add('hidden');
    recoveryCard.classList.remove('hidden');
    passwordSectionTitle.textContent = 'Change Master Password';
    savePasswordBtn.textContent = 'Update Password';

    if (await hasSecurityQuestions()) {
      recoveryBadge.textContent = 'Security questions are set';
      recoveryBadge.classList.remove('warn');
    } else {
      recoveryBadge.textContent = 'Not set up - a forgotten password cannot be recovered';
      recoveryBadge.classList.add('warn');
    }
  } else {
    currentPasswordWrapper.style.display = 'none';
    recoveryFieldWrapper.classList.remove('hidden');
    recoveryCard.classList.add('hidden');
    passwordSectionTitle.textContent = 'Create Master Password';
    savePasswordBtn.textContent = 'Save Password & Lock Browser';
  }

  lockOnStartupCheckbox.checked = lockOnStartup !== false;
  autoLockSelect.value = String(autoLockMinutes || 0);
}

// ---------- Save password (first time + change) ----------
passwordForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  passwordStatus.textContent = '';

  const { passwordHash, passwordSalt } = await chrome.storage.local.get([
    'passwordHash',
    'passwordSalt'
  ]);
  const isFirstTime = !passwordHash;

  if (!isFirstTime) {
    const currentValid = await verifyPassword(
      currentPasswordInput.value,
      passwordHash,
      passwordSalt
    );
    if (!currentValid) {
      setStatus(passwordStatus, 'Current password is incorrect.');
      return;
    }
  }

  const newPass = newPasswordInput.value;
  const confirmPass = confirmPasswordInput.value;

  if (newPass.length < 4) {
    setStatus(passwordStatus, 'Password must be at least 4 characters long.');
    return;
  }
  if (newPass !== confirmPass) {
    setStatus(passwordStatus, 'New passwords do not match.');
    return;
  }

  // Security questions are required on first-time setup (they are the only recovery option)
  let securityRecord = null;
  if (isFirstTime) {
    const built = await buildSecurityRecord(readAnswers(setupInputs));
    if (!built.ok) {
      setStatus(passwordStatus, built.error);
      return;
    }
    securityRecord = built.record;
  }

  savePasswordBtn.disabled = true;
  try {
    const { hash, salt } = await hashPassword(newPass);
    const toSave = { passwordHash: hash, passwordSalt: salt };
    if (securityRecord) toSave.securityAnswers = securityRecord;
    await chrome.storage.local.set(toSave);

    currentPasswordInput.value = '';
    newPasswordInput.value = '';
    confirmPasswordInput.value = '';
    clearAnswers(setupInputs);

    if (isFirstTime) {
      setStatus(passwordStatus, 'Password saved! Locking your browser...', true);
      setTimeout(() => {
        chrome.runtime.sendMessage({ action: 'LOCK_BROWSER' });
      }, 700);
    } else {
      setStatus(passwordStatus, 'Master password updated successfully!', true);
      await loadSettings();
    }
  } finally {
    savePasswordBtn.disabled = false;
  }
});

// ---------- Security questions card (change answers) ----------
recoveryForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  recoveryStatus.textContent = '';

  const { passwordHash, passwordSalt } = await chrome.storage.local.get([
    'passwordHash',
    'passwordSalt'
  ]);
  if (!(await verifyPassword(recoveryPassword.value, passwordHash, passwordSalt))) {
    setStatus(recoveryStatus, 'Master password is incorrect.');
    return;
  }

  const built = await buildSecurityRecord(readAnswers(editInputs));
  if (!built.ok) {
    setStatus(recoveryStatus, built.error);
    return;
  }

  await chrome.storage.local.set({ securityAnswers: built.record });
  await clearRecoveryFailures();

  recoveryPassword.value = '';
  clearAnswers(editInputs);
  setStatus(recoveryStatus, 'Security answers saved!', true);
  await loadSettings();
});

// ---------- Preferences ----------
lockOnStartupCheckbox.addEventListener('change', async () => {
  await chrome.storage.local.set({ lockOnStartup: lockOnStartupCheckbox.checked });
  showPrefSaved();
});

autoLockSelect.addEventListener('change', async () => {
  await chrome.storage.local.set({ autoLockMinutes: Number(autoLockSelect.value) });
  showPrefSaved();
});

function showPrefSaved() {
  prefStatus.style.color = '#22c55e';
  prefStatus.textContent = 'Preferences saved.';
  setTimeout(() => {
    prefStatus.textContent = '';
  }, 2000);
}

lockNowBtn.addEventListener('click', async () => {
  const { passwordHash } = await chrome.storage.local.get('passwordHash');
  if (!passwordHash) {
    setStatus(passwordStatus, 'Please set a master password first before locking.');
    return;
  }
  await chrome.runtime.sendMessage({ action: 'LOCK_BROWSER' });
});

loadSettings();
