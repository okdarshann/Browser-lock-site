// lock-anim.js - The 3D padlock on the lock screen.
//   * initLockAnimation()   : the padlock gently follows the mouse (and wanders when idle)
//   * playUnlockAnimation() : the shackle lifts and swings open; resolves when it has finished
//
// This lives in its own file because extension pages cannot run inline <script> tags.

const OPEN_MS = 1250;          // full "open" sequence (keep in sync with --xb-open-ms in lock.html)
const OPEN_MS_REDUCED = 350;   // when the system asks for reduced motion

let ball = null;
let orb = null;
let body = null;
let shackle = null;
let calm = false;
let opened = false;

export function initLockAnimation() {
  ball = document.getElementById('xb-ball');
  if (!ball) return;
  orb = ball.querySelector('.xb-orb');
  body = orb.querySelector('.xb-orb-b');
  shackle = orb.querySelector('.xb-shackle');
  calm = Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  let tx = 0;
  let ty = 0;
  let cx = 0;
  let cy = 0;
  let last = 0;
  let nextIdle = 0;
  const clamp = (v) => Math.max(-1, Math.min(1, v));

  window.addEventListener(
    'pointermove',
    (e) => {
      const r = orb.getBoundingClientRect();
      if (!r.width) return;
      tx = clamp((e.clientX - (r.left + r.width / 2)) / 420);
      ty = clamp((e.clientY - (r.top + r.height / 2)) / 420);
      last = performance.now();
    },
    { passive: true }
  );

  document.documentElement.addEventListener('mouseleave', () => {
    tx = 0;
    ty = 0;
  });

  function frame(now) {
    requestAnimationFrame(frame);
    if (document.hidden || !orb.getClientRects().length) return;

    // Idle: look around by itself every few seconds
    if (now - last > 3500 && now > nextIdle) {
      tx = Math.random() - 0.5;
      ty = (Math.random() - 0.5) * 0.6;
      nextIdle = now + 1600 + Math.random() * 1800;
    }

    cx += (tx - cx) * 0.1;
    cy += (ty - cy) * 0.1;

    if (!calm) {
      const tilt = `rotateY(${cx * 8}deg) rotateX(${-cy * 7}deg)`;
      body.style.transform = tilt;
      // Once the shackle is opening, its own animation takes over
      if (!opened) shackle.style.transform = tilt;
    }
  }
  requestAnimationFrame(frame);
}

// Opens the lock. Call this after a correct password / recovery and BEFORE telling the
// background script to unlock (unlocking navigates this tab away, which ends the animation).
export function playUnlockAnimation() {
  return new Promise((resolve) => {
    if (!ball || opened) {
      resolve();
      return;
    }
    opened = true;
    shackle.style.transform = ''; // hand control to the CSS animation
    ball.classList.add('opening');
    setTimeout(resolve, calm ? OPEN_MS_REDUCED : OPEN_MS);
  });
}

// Closes the lock again (only used if unlocking failed after the animation started)
export function resetUnlockAnimation() {
  if (!ball) return;
  opened = false;
  ball.classList.remove('opening');
}
