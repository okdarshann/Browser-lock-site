// security-utils.js - Security questions used to recover a forgotten master password.
//
// How it works:
//   * The user answers 3 fixed questions when creating the password.
//   * Answers are NEVER stored as text. Each one is normalized, then hashed with its own
//     random salt (PBKDF2, same as the master password) and saved in chrome.storage.local.
//   * To recover, ALL 3 answers must be correct. The lock screen never says which one was wrong.
//   * Wrong guesses are limited by a lockout that is saved in storage, so reloading the
//     page does not reset it.
import { hashPassword, verifyPassword } from './crypto-utils.js';

// ---------- The 3 questions ----------
// type 'text'    -> any words (compared ignoring capital letters and extra spaces)
// type 'integer' -> whole number only
export const SECURITY_QUESTIONS = [
  {
    id: 'name',
    type: 'text',
    label: 'What would your other name be, if you had the chance to name yourself?',
    placeholder: 'The name you would give yourself'
  },
  {
    id: 'years',
    type: 'integer',
    label: 'Approximately how many years will you live in this world?',
    placeholder: 'Whole number only, e.g. 80'
  },
  {
    id: 'crush',
    type: 'text',
    label: 'Who is your crush?',
    placeholder: 'Their name'
  }
];

const MIN_TEXT_LENGTH = 2;
const MAX_INTEGER_DIGITS = 4;

// ---------- Answer cleaning ----------

// Keeps only digits (used live while the user types in the number field)
export function sanitizeIntegerInput(inputEl) {
  inputEl.value = inputEl.value.replace(/\D/g, '').slice(0, MAX_INTEGER_DIGITS);
}

// Turns what the user typed into the exact string that gets hashed.
// Returns '' when the answer is not usable.
export function normalizeAnswer(question, raw) {
  const text = String(raw == null ? '' : raw).normalize('NFKC').trim();

  if (question.type === 'integer') {
    if (!new RegExp(`^\\d{1,${MAX_INTEGER_DIGITS}}$`).test(text)) return '';
    const value = parseInt(text, 10);
    return value > 0 ? String(value) : ''; // "080" and "80" are the same answer
  }

  const cleaned = text.toLowerCase().replace(/\s+/g, ' ');
  return cleaned.length >= MIN_TEXT_LENGTH ? cleaned : '';
}

// rawAnswers = { name: '...', years: '...', crush: '...' }
// Returns { ok: true } or { ok: false, error }
export function validateAnswers(rawAnswers) {
  for (const q of SECURITY_QUESTIONS) {
    const typed = String((rawAnswers && rawAnswers[q.id]) || '').trim();
    if (!typed) {
      return { ok: false, error: 'Please answer all 3 questions.' };
    }
    if (!normalizeAnswer(q, typed)) {
      return {
        ok: false,
        error:
          q.type === 'integer'
            ? 'The number of years must be a whole number (digits only, more than 0).'
            : `Each text answer needs at least ${MIN_TEXT_LENGTH} characters.`
      };
    }
  }
  return { ok: true };
}

// ---------- Saving ----------

// Hashes the 3 answers. Returns { ok: true, record } or { ok: false, error }.
// The caller saves `record` as `securityAnswers` in chrome.storage.local.
export async function buildSecurityRecord(rawAnswers) {
  const check = validateAnswers(rawAnswers);
  if (!check.ok) return check;

  const record = {};
  for (const q of SECURITY_QUESTIONS) {
    const { hash, salt } = await hashPassword(normalizeAnswer(q, rawAnswers[q.id]));
    record[q.id] = { hash, salt };
  }
  return { ok: true, record };
}

export async function hasSecurityQuestions() {
  const { securityAnswers } = await chrome.storage.local.get('securityAnswers');
  return SECURITY_QUESTIONS.every(
    (q) => securityAnswers && securityAnswers[q.id] && securityAnswers[q.id].hash && securityAnswers[q.id].salt
  );
}

// ---------- Checking ----------

// True only if ALL 3 answers match. All three are always checked, so the time taken
// does not reveal which one was wrong.
export async function verifySecurityAnswers(rawAnswers) {
  const { securityAnswers } = await chrome.storage.local.get('securityAnswers');
  if (!securityAnswers) return false;

  const results = await Promise.all(
    SECURITY_QUESTIONS.map((q) => {
      const saved = securityAnswers[q.id];
      const normalized = normalizeAnswer(q, rawAnswers && rawAnswers[q.id]);
      if (!saved || !normalized) return false;
      return verifyPassword(normalized, saved.hash, saved.salt);
    })
  );
  return results.every(Boolean);
}

// ---------- Lockout after wrong answers ----------
// Every 3 wrong tries lock recovery for a while, and each new lockout is twice as long:
// 5 min, 10 min, 20 min, 40 min, then 60 min at most.
export const FREE_TRIES = 3;
const BASE_LOCKOUT_MS = 5 * 60 * 1000;
const MAX_LOCKOUT_MS = 60 * 60 * 1000;
const LOCKOUT_KEYS = ['recoveryFails', 'recoveryRounds', 'recoveryLockUntil'];

// Milliseconds the user still has to wait (0 = can try now)
export async function getRecoveryLockoutMs() {
  const { recoveryLockUntil = 0 } = await chrome.storage.local.get('recoveryLockUntil');
  return Math.max(0, recoveryLockUntil - Date.now());
}

// Call after a wrong attempt. Returns { lockedMs, triesLeft }
export async function recordRecoveryFailure() {
  const { recoveryFails = 0, recoveryRounds = 0 } = await chrome.storage.local.get([
    'recoveryFails',
    'recoveryRounds'
  ]);

  const fails = recoveryFails + 1;
  if (fails >= FREE_TRIES) {
    const lockedMs = Math.min(BASE_LOCKOUT_MS * 2 ** recoveryRounds, MAX_LOCKOUT_MS);
    await chrome.storage.local.set({
      recoveryFails: 0,
      recoveryRounds: recoveryRounds + 1,
      recoveryLockUntil: Date.now() + lockedMs
    });
    return { lockedMs, triesLeft: 0 };
  }

  await chrome.storage.local.set({ recoveryFails: fails });
  return { lockedMs: 0, triesLeft: FREE_TRIES - fails };
}

// Call after a correct recovery (or when the owner re-saves the answers with the master password)
export async function clearRecoveryFailures() {
  await chrome.storage.local.remove(LOCKOUT_KEYS);
}

export function formatWait(ms) {
  const seconds = Math.ceil(ms / 1000);
  if (seconds <= 90) return `${Math.max(1, seconds)} seconds`;
  return `${Math.ceil(seconds / 60)} minutes`;
}
