# Browser Lock

**Browser Lock** is a secure, modern Chrome extension that protects your browsing session and profile with a master password. It locks open tabs automatically when Chrome or your profile starts, shields new tabs and windows while locked, and preserves your active tabs upon unlocking—all while keeping your Chrome account data, cookies, and Google Sync 100% untouched.

---

![Browser Lock](lock1.png)
![Browser Lock](lock2.png)

## Key Features
- **Zero Chrome Account Interference:** Uses local and session storage exclusively. It never interferes with Google Account sign-ins, token refreshes, browsing data, or cloud sync.
- **Animated 3D Padlock:** The lock screen shows a steel-and-graphite padlock that follows your mouse. When you unlock (by password or by answering your security questions) the shackle lifts and swings open before your tabs come back. It respects the system's *reduce motion* setting.
- **True Black / Obsidian Dark Theme:** Features a sleek, high-contrast monochrome dark mode designed for privacy and comfort.
- **Inline Password Management:** Change your master password directly from the `Browser Locked` screen or via the extension settings.
- **Forgot Password (3 security questions):** While creating your password you answer 3 personal questions. If you ever forget the password, click **Forgot Password?** on the lock screen, answer the same 3 questions correctly, and the browser unlocks - you can then set a new password. No email, no internet, no accounts.
- **Smart Profile Reopening Protection:** Automatically detects when all windows of your Chrome profile are closed and locks the session upon reopening.
- **Non-Destructive Tab Restoration:** Remembers your original tab URLs while locked and restores them instantly when you enter your password.
- **Quick-Lock & Auto-Lock:** Press `Alt + L` or click the extension icon to lock immediately, or configure an idle timer in Settings.

---

## Installation Guide

### Option A: Install Locally (Recommended for Developers)
1. Download and extract the project folder.
2. Open Chrome and navigate to `chrome://extensions/`.
3. Enable **Developer mode** using the toggle switch in the top-right corner.
4. Click **Load unpacked** in the top-left corner.
5. Select the **`Browser-Lock`** folder containing `manifest.json`.
6. Click the extensions puzzle icon in Chrome and **pin Browser Lock** for quick access.

---

## How to Use

1. **Set Up Your Password (first time):**
   * The settings page opens automatically after install (or click the extension icon).
   * Enter and confirm your master password.
   * Answer the **3 security questions** (required - they are the only way to recover a forgotten password).
   * Click **Save Password & Lock Browser**.
   * The browser locks right away: the lock page opens and every other tab is locked too.
2. **Lock Your Browser:**
   * Click **Lock Browser Now** in settings, press `Alt + L`, or click the extension icon.
   * Closing all windows of your Chrome profile and reopening Chrome also shows the lock screen.
3. **Unlock & Restore:**
   * Enter your master password and press **Unlock Browser**. All tabs are restored.
4. **Change Your Password:**
   * Click **Change Password** on the lock screen (or in settings), verify your current password, and set a new one.
5. **Forgot Your Password?**
   * Click **Forgot Password?** on the lock screen.
   * Answer all 3 security questions (see below). If every answer is correct, the browser unlocks and you can choose **Set New Password & Unlock**, or **Unlock Without Changing Password**.
   * The lock screen never tells you *which* answer was wrong.
   * After 3 wrong tries, recovery is locked for 5 minutes. Each further lockout doubles (10, 20, 40 min) up to 60 minutes. The lockout is saved, so closing or reloading the page does not reset it.
6. **Change Your Security Answers:**
   * Open settings > **Security Questions**, enter all 3 new answers and your master password.

### The 3 security questions

| # | Question | Answer type |
|---|----------|-------------|
| 1 | What would your other name be, if you had the chance to name yourself? | Text |
| 2 | Approximately how many years will you live in this world? | Whole number only (1-4 digits) |
| 3 | Who is your crush? | Text |

Text answers ignore capital letters and extra spaces (`  Dark  KNIGHT ` = `dark knight`). Number answers ignore leading zeros (`080` = `80`). Choose answers you will still remember in a year - they cannot be shown again, only replaced.

**Upgrading from the email version (2.3.x):** the old recovery email is deleted automatically. Your password keeps working; open settings > **Security Questions** once to add your answers, otherwise a forgotten password cannot be recovered.

---

## Privacy & Security
- **Local-Only Storage:** Your password hash and salt are generated with the native Web Crypto API (`PBKDF2`, `SHA-256`, 100,000 iterations) and stored only in your Chrome profile (`chrome.storage.local`).
- **Security answers are hashed too:** each of the 3 answers is normalized and stored as its own salted PBKDF2 hash. The answers themselves are never saved.
- **No network use at all:** Browser Lock works completely offline and sends nothing anywhere.
- **Permissions:** `storage`, `tabs`, `idle` only.
- **Honest limitations:**
  * Security answers are easier to guess than a good password (especially the number question), so choose answers other people could not guess, and rely on the lockout to slow guessing.
  * Like any extension-based lock, this stops casual access to your browser, not someone who can open `chrome://extensions` and remove the extension. Treat it as a privacy screen, not a vault.

---

## License
This project is licensed under the **MIT License**.
