// lock.js - Handles password verification, brute-force protection, inline password changes,
// and password recovery through the 3 security questions
import { hashPassword, verifyPassword } from './crypto-utils.js';
import { initLockAnimation, playUnlockAnimation, resetUnlockAnimation } from './lock-anim.js';
import {
  SECURITY_QUESTIONS,
  FREE_TRIES,
  sanitizeIntegerInput,
  validateAnswers,
  hasSecurityQuestions,
  verifySecurityAnswers,
  getRecoveryLockoutMs,
  recordRecoveryFailure,
  clearRecoveryFailures,
  formatWait
} from './security-utils.js';

initLockAnimation();

// Opens the padlock first, THEN unlocks (unlocking navigates this tab away, so it must come last)
async function openAndUnlock() {
  try {
    await playUnlockAnimation();
    await chrome.runtime.sendMessage({ action: 'UNLOCK_BROWSER' });
  } catch (err) {
    resetUnlockAnimation();
    throw err;
  }
}

const lockCard = document.getElementById('lockCard');
const unlockView = document.getElementById('unlockView');
const changePassView = document.getElementById('changePassView');
const forgotView = document.getElementById('forgotView');

// Unlock Elements
const unlockForm = document.getElementById('unlockForm');
const passwordInput = document.getElementById('passwordInput');
const toggleBtn = document.getElementById('togglePassword');
const unlockBtn = document.getElementById('unlockBtn');
const statusMsg = document.getElementById('statusMsg');
const showChangePassBtn = document.getElementById('showChangePassBtn');

// Change Password Elements
const changePassForm = document.getElementById('changePassForm');
const oldPassInput = document.getElementById('oldPassInput');
const newPassInput = document.getElementById('newPassInput');
const confirmPassInput = document.getElementById('confirmPassInput');
const savePassBtn = document.getElementById('savePassBtn');
const backToUnlockBtn = document.getElementById('backToUnlockBtn');
const changePassMsg = document.getElementById('changePassMsg');

let failedAttempts = 0;
let cooldownUntil = 0;

// Toggle password visibility on unlock screen
toggleBtn.addEventListener('click', () => {
  const isPassword = passwordInput.type === 'password';
  passwordInput.type = isPassword ? 'text' : 'password';
  passwordInput.focus();
});

// Switch between Unlock, Change Password and Forgot Password views
const allViews = { unlock: unlockView, change: changePassView, forgot: forgotView };

function showView(name) {
  statusMsg.textContent = '';
  changePassMsg.textContent = '';
  Object.entries(allViews).forEach(([key, el]) => el.classList.toggle('hidden', key !== name));
}

showChangePassBtn.addEventListener('click', () => {
  showView('change');
  oldPassInput.focus();
});

backToUnlockBtn.addEventListener('click', () => {
  changePassForm.reset();
  showView('unlock');
  passwordInput.focus();
});

// Trigger shake animation
function triggerShake(targetMsgElement, message) {
  targetMsgElement.style.color = '#ef4444';
  targetMsgElement.textContent = message;
  lockCard.classList.remove('shake');
  void lockCard.offsetWidth; // Force reflow
  lockCard.classList.add('shake');
}

// Handle Unlock Submit
unlockForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const now = Date.now();
  if (now < cooldownUntil) {
    const remaining = Math.ceil((cooldownUntil - now) / 1000);
    triggerShake(statusMsg, `Too many attempts. Try again in ${remaining}s.`);
    return;
  }

  const inputPassword = passwordInput.value;
  if (!inputPassword) return;

  unlockBtn.disabled = true;
  statusMsg.textContent = '';

  try {
    const { passwordHash, passwordSalt } = await chrome.storage.local.get([
      'passwordHash',
      'passwordSalt'
    ]);

    if (!passwordHash || !passwordSalt) {
      await chrome.runtime.sendMessage({ action: 'UNLOCK_BROWSER' });
      return;
    }

    const isValid = await verifyPassword(inputPassword, passwordHash, passwordSalt);

    if (isValid) {
      failedAttempts = 0;
      statusMsg.style.color = '#22c55e';
      statusMsg.textContent = 'Unlocked! Restoring your tabs...';
      await openAndUnlock();
    } else {
      failedAttempts++;
      passwordInput.value = '';
      passwordInput.focus();

      if (failedAttempts >= 5) {
        cooldownUntil = Date.now() + 15000;
        triggerShake(statusMsg, '5 failed attempts. Locked for 15 seconds.');
      } else {
        triggerShake(statusMsg, `Incorrect password (${5 - failedAttempts} attempts remaining)`);
      }
    }
  } catch (err) {
    triggerShake(statusMsg, 'An error occurred while verifying password.');
  } finally {
    unlockBtn.disabled = false;
  }
});

// Handle Change Password Submit on Lock Screen
changePassForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const now = Date.now();
  if (now < cooldownUntil) {
    const remaining = Math.ceil((cooldownUntil - now) / 1000);
    triggerShake(changePassMsg, `Too many attempts. Try again in ${remaining}s.`);
    return;
  }

  const oldPass = oldPassInput.value;
  const newPass = newPassInput.value;
  const confirmPass = confirmPassInput.value;

  if (newPass.length < 4) {
    triggerShake(changePassMsg, 'New password must be at least 4 characters.');
    return;
  }

  if (newPass !== confirmPass) {
    triggerShake(changePassMsg, 'New passwords do not match.');
    return;
  }

  savePassBtn.disabled = true;
  changePassMsg.textContent = '';

  try {
    const { passwordHash, passwordSalt } = await chrome.storage.local.get([
      'passwordHash',
      'passwordSalt'
    ]);

    if (passwordHash && passwordSalt) {
      const isCurrentValid = await verifyPassword(oldPass, passwordHash, passwordSalt);
      if (!isCurrentValid) {
        failedAttempts++;
        oldPassInput.value = '';
        oldPassInput.focus();
        if (failedAttempts >= 5) {
          cooldownUntil = Date.now() + 15000;
          triggerShake(changePassMsg, '5 failed attempts. Locked for 15 seconds.');
        } else {
          triggerShake(changePassMsg, `Current password incorrect (${5 - failedAttempts} tries left)`);
        }
        return;
      }
    }

    const { hash, salt } = await hashPassword(newPass);
    await chrome.storage.local.set({
      passwordHash: hash,
      passwordSalt: salt
    });

    failedAttempts = 0;
    changePassMsg.style.color = '#22c55e';
    changePassMsg.textContent = 'Password updated! Unlocking browser...';

    await openAndUnlock();
  } catch (err) {
    triggerShake(changePassMsg, 'Failed to update password.');
  } finally {
    savePassBtn.disabled = false;
  }
});


// ======================= FORGOT PASSWORD (3 security questions) =======================
const showForgotBtn = document.getElementById('showForgotBtn');
const forgotQuestionsStep = document.getElementById('forgotQuestionsStep');
const forgotResetStep = document.getElementById('forgotResetStep');
const noQuestionsBox = document.getElementById('noQuestionsBox');
const questionsForm = document.getElementById('questionsForm');
const answerFields = document.getElementById('answerFields');
const verifyAnswersBtn = document.getElementById('verifyAnswersBtn');
const toggleAnswersBtn = document.getElementById('toggleAnswersBtn');
const questionsMsg = document.getElementById('questionsMsg');
const forgotBackBtn0 = document.getElementById('forgotBackBtn0');
const forgotBackBtn1 = document.getElementById('forgotBackBtn1');

const resetForm = document.getElementById('resetForm');
const resetNewPass = document.getElementById('resetNewPass');
const resetConfirmPass = document.getElementById('resetConfirmPass');
const resetBtn = document.getElementById('resetBtn');
const skipResetBtn = document.getElementById('skipResetBtn');
const resetMsg = document.getElementById('resetMsg');

// The answers that passed verification. Kept only in this page's memory (never saved),
// and checked again right before the lock is opened.
let verifiedAnswers = null;
const answerInputs = {};
let answersVisible = false;

// Build one input per question from the shared list in security-utils.js
SECURITY_QUESTIONS.forEach((q) => {
  const group = document.createElement('div');
  group.className = 'input-group';

  const label = document.createElement('label');
  label.className = 'q-label';
  label.htmlFor = `answer-${q.id}`;
  label.textContent = q.label;

  const box = document.createElement('div');
  box.className = 'input-box';

  const input = document.createElement('input');
  input.type = 'password';
  input.id = `answer-${q.id}`;
  input.placeholder = q.placeholder;
  input.autocomplete = 'off';
  input.spellcheck = false;
  if (q.type === 'integer') {
    input.inputMode = 'numeric';
    input.maxLength = 4;
    input.addEventListener('input', () => sanitizeIntegerInput(input));
  }

  box.appendChild(input);
  group.append(label, box);
  answerFields.appendChild(group);
  answerInputs[q.id] = input;
});

function readAnswers() {
  const answers = {};
  SECURITY_QUESTIONS.forEach((q) => {
    answers[q.id] = answerInputs[q.id].value;
  });
  return answers;
}

function setAnswersVisible(visible) {
  answersVisible = visible;
  Object.values(answerInputs).forEach((input) => {
    input.type = visible ? 'text' : 'password';
  });
  toggleAnswersBtn.textContent = visible ? 'Hide answers' : 'Show answers';
}

toggleAnswersBtn.addEventListener('click', () => setAnswersVisible(!answersVisible));

function showQuestionsStep() {
  forgotQuestionsStep.classList.remove('hidden');
  forgotResetStep.classList.add('hidden');
}

function clearForgotState() {
  verifiedAnswers = null;
  questionsForm.reset();
  resetForm.reset();
  setAnswersVisible(false);
  questionsMsg.textContent = '';
  resetMsg.textContent = '';
  showQuestionsStep();
}

function goBackToUnlock() {
  clearForgotState();
  showView('unlock');
  passwordInput.focus();
}

forgotBackBtn0.addEventListener('click', goBackToUnlock);
forgotBackBtn1.addEventListener('click', goBackToUnlock);

function showLockoutMessage(waitMs) {
  triggerShake(questionsMsg, `Too many wrong answers. Try again in ${formatWait(waitMs)}.`);
}

showForgotBtn.addEventListener('click', async () => {
  clearForgotState();
  showView('forgot');

  const configured = await hasSecurityQuestions();
  noQuestionsBox.classList.toggle('hidden', configured);
  questionsForm.classList.toggle('hidden', !configured);
  forgotBackBtn0.classList.toggle('hidden', configured);
  if (!configured) return;

  const wait = await getRecoveryLockoutMs();
  if (wait > 0) {
    showLockoutMessage(wait);
  }
  answerInputs[SECURITY_QUESTIONS[0].id].focus();
});

// Step A: check the 3 answers
questionsForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const wait = await getRecoveryLockoutMs();
  if (wait > 0) {
    showLockoutMessage(wait);
    return;
  }

  const answers = readAnswers();
  const check = validateAnswers(answers);
  if (!check.ok) {
    // Wrong format / empty field: not counted as a failed guess
    triggerShake(questionsMsg, check.error);
    return;
  }

  verifyAnswersBtn.disabled = true;
  questionsMsg.textContent = '';

  try {
    if (await verifySecurityAnswers(answers)) {
      await clearRecoveryFailures();
      verifiedAnswers = answers;
      questionsForm.reset();
      setAnswersVisible(false);
      questionsMsg.textContent = '';
      forgotQuestionsStep.classList.add('hidden');
      forgotResetStep.classList.remove('hidden');
      resetNewPass.focus();
      return;
    }

    // Never say WHICH answer was wrong
    const result = await recordRecoveryFailure();
    Object.values(answerInputs).forEach((input) => { input.value = ''; });
    answerInputs[SECURITY_QUESTIONS[0].id].focus();

    if (result.lockedMs > 0) {
      triggerShake(
        questionsMsg,
        `${FREE_TRIES} wrong attempts. Recovery is locked for ${formatWait(result.lockedMs)}.`
      );
    } else {
      triggerShake(
        questionsMsg,
        `One or more answers are incorrect (${result.triesLeft} ${result.triesLeft === 1 ? 'try' : 'tries'} left).`
      );
    }
  } catch (err) {
    triggerShake(questionsMsg, 'Something went wrong. Please try again.');
  } finally {
    verifyAnswersBtn.disabled = false;
  }
});

// Confirms the saved answers still match before the lock is opened in step B
async function answersStillValid() {
  if (!verifiedAnswers) return false;
  if (await verifySecurityAnswers(verifiedAnswers)) return true;
  // Should never happen; send the user back to step A
  clearForgotState();
  triggerShake(questionsMsg, 'Please answer the questions again.');
  return false;
}

async function finishUnlock(message) {
  failedAttempts = 0;
  cooldownUntil = 0;
  verifiedAnswers = null;
  resetMsg.style.color = '#22c55e';
  resetMsg.textContent = message;
  await openAndUnlock();
}

// Step B (option 1): set a new password and unlock
resetForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const newPass = resetNewPass.value;
  const confirmPass = resetConfirmPass.value;

  if (newPass.length < 4) {
    triggerShake(resetMsg, 'New password must be at least 4 characters.');
    return;
  }
  if (newPass !== confirmPass) {
    triggerShake(resetMsg, 'New passwords do not match.');
    return;
  }

  resetBtn.disabled = true;
  skipResetBtn.disabled = true;
  try {
    if (!(await answersStillValid())) return;

    const { hash, salt } = await hashPassword(newPass);
    await chrome.storage.local.set({ passwordHash: hash, passwordSalt: salt });
    await finishUnlock('Password changed! Unlocking browser...');
  } catch (err) {
    triggerShake(resetMsg, 'Something went wrong. Please try again.');
  } finally {
    resetBtn.disabled = false;
    skipResetBtn.disabled = false;
  }
});

// Step B (option 2): unlock and keep the current password
skipResetBtn.addEventListener('click', async () => {
  resetBtn.disabled = true;
  skipResetBtn.disabled = true;
  try {
    if (!(await answersStillValid())) return;
    await finishUnlock('Unlocked! Restoring your tabs...');
  } catch (err) {
    triggerShake(resetMsg, 'Something went wrong. Please try again.');
  } finally {
    resetBtn.disabled = false;
    skipResetBtn.disabled = false;
  }
});
